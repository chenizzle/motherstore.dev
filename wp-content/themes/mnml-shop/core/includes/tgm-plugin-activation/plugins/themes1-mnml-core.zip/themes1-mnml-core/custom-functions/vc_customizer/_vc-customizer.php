<?php

include_once('vc_custom-grid.php'); ## Custom Grid
include_once('vc_row_params.php'); ## Adds custom parameters to VC_ROW
include_once('vc_column_params.php'); ## Adds custom parameters to VC_COLUMN
include_once('vc_column_inner_params.php'); ## Adds a custom parameter to VC_COLUMN_INNER
include_once('vc_custom_params.php'); ## Create custom parameter

?>
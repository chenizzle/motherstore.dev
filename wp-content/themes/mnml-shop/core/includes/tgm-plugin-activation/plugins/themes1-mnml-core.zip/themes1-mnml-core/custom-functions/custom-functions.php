<?php
require_once('vc_customizer/_vc-customizer.php'); ### Adding the changes to VC default widgets
require_once('widgets/widgets.php'); ### Wordpress Widgets
require_once('_other-shortcodes.php');
require_once('importer/import.php');	

?>
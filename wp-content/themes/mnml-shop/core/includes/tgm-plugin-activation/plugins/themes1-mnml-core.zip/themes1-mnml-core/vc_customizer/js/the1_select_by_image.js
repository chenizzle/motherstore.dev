!function($) {
	/* Skripta */
}(window.jQuery);
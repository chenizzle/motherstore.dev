<?php
require_once('_instagram-widget.php'); ### Instagram widget which is shown in Woocommerce

?>
<?php
require_once('custom-params.php'); ### Our custom parameter for styles


?>
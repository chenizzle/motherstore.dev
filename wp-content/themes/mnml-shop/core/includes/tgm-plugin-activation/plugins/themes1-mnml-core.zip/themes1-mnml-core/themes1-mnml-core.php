<?php
 
/*
Plugin Name: Themes1 Mnml Core
Plugin URI: 
Description: Mnml theme functionality 
Author: Veton Siqani, Fisnik Tahiri
Version: 1.1
Author URI:
Text Domain: themes1-mnml-core
*/


require_once('custom-functions/custom-functions.php'); ## Other Options

require_once('vc_widgets/vc_widgets.php'); ## Custom Visual Composer parameters
require_once('vc_customizer/vc_customizer.php'); ## Custom Visual Composer functions
require_once('product-slider/slider.php'); ## Woocommerce Products Slider for Homepage
require_once('slider/slider.php'); ## Custom The1 Slider

?>